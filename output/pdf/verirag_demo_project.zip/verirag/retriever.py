"""Illustrative token matching; not an evaluated research system."""
def retrieve(query, passages):
    tokens = set(query.lower().split())
    return sorted(passages, key=lambda text: len(tokens & set(text.lower().split())), reverse=True)
